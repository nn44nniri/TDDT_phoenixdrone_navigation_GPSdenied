#Loading the environment and prerequisites:

```bash
cd /media/p1/DigitalTwin/TDDT_navigation/TDOC/code/chatgpg/reference_v4/TDDT_integrated_fix_v4/TDOC_v20260911_2052
source configs/environment_fixed.sh
```



```bash
$PYTHON -m pip install --upgrade pip setuptools wheel
```



```bash
$PYTHON -m pip install \
  -r "$TDDT_ORCHESTRATOR_ROOT/requirements.txt" \
  -r "$TDDT_BOULDER_ROOT/requirements.txt" \
  -r "$TDDT_SARG_PACKAGE_ROOT/requirements.txt" \
  -r "$TDDT_CLIMATE_ROOT/requirements.txt" \
  -r "$TDDT_LAYER3_ROOT/requirements.txt" \
  -r "$TDDT_LAYER4_ROOT/requirements.txt" \
  -r "$TDDT_LAYER5_ROOT/requirements.txt" \
  -r "$TDDT_LAYER7_ROOT/requirements.txt"
```


#Compiling, retrieving internet-dependent data, and constructing datasets:

```bash
tddt-tdoc --config configs/tdoc.yaml reset \
  --refresh-external \
  --build-fmus \
  --build-fmus-refresh
```

#Building a digital twin incorporating the ArduPilot flight controller and the JSBSim simulator:

The installation entrypoint including Phoenix MAVProxy artwork is
`install_flightstack_with_phoenix_icons.sh`. It runs the existing
`install_flightstack_rev1.sh` first, then installs the presentation-only patch.
For a fresh installation, set `TDDT_FLIGHTSTACK_ASSETS` to the directory containing
the prerequisite, Phoenix model, Environment Adapter, controller and dataset
archives plus `region_v1.geojson`, as listed in the Layer-6 installation guide.
Those archives are external installation inputs; this bundle does not contain an
`essential_data/` directory. The installer also searches its current directory
and its `scripts/` directory.

```bash
: "${TDDT_FLIGHTSTACK_ASSETS:?Set this to your existing FlightStack installation-assets directory}"
"$TDDT_LAYER6_ROOT/scripts/install_flightstack_with_phoenix_icons.sh" \
  --base-dir "$TDDT_LAYER6_ROOT" \
  --assets-dir "$TDDT_FLIGHTSTACK_ASSETS"
```

An existing installed FlightStack does not need reinstallation before Online.
Install the Phoenix map icons once on that existing stack, without rebuilding
or resetting the accepted Offline knowledge:

```bash
bash "$TDDT_LAYER6_ROOT/scripts/install_flightstack_with_phoenix_icons.sh" \
  --base-dir "$TDDT_LAYER6_ROOT" --icons-only
```

The five supplied Phoenix colors replace aircraft icon aliases in this bundle's
native MAVProxy only. Its relocated launcher is bound to the same local Python.
Map markers and telemetry/control code are preserved. After reinstalling or
upgrading MAVProxy, rerun the icon installation (the full installation entrypoint
above already does this). See `presentation/phoenix_mavproxy_icons/README_FA.md`.

Its map/Console Python dependencies can be checked without starting a simulator:

```bash
"$TDDT_LAYER6_ROOT/scripts/install_flightstack_rev1.sh" \
  --base-dir "$TDDT_LAYER6_ROOT" --check-replay-map
```

Native startup opens ArduPilot/JSBSim, Environment Adapter and Phoenix GUI, plus
the MAVProxy map and Console on the same FCU stream. Session status requires fresh
map/Console evidence; screenshots and flight telemetry remain required for an
Online acceptance result.

The canonical configuration selects `layers.layer6.online.execution_profile:
closed_loop_sitl`. TDOC composes the existing Layer2/Layer3/Layer4 prediction and
Layer5 MPC/safety pipeline with the Native execution contract. Layer5 owns MODE
and ARM intent; Layer6 waits for fresh FCU confirmation before the first pilot
write. Each bounded execution returns measured telemetry and transaction-bound
prediction/execution residuals through Layer7. Model prediction is guidance; this
profile does not certify ArduPilot's internal controller or authorize field flight.
Simulation diagnostics do not grant persistent field-learning authority.

The JSBSim window is a live observer of the existing ArduPilot-owned JSBSim child,
its PID/log and the same FCU telemetry. It does not launch a second simulator.
All required Native components, map and Console are checked throughout Online;
closing a required component rejects subsequent control execution.

Source changes invalidate hash-bound model certificates. Preserve the old
runtime/KStore and create a fresh Offline episode under the completed source
version when reuse is rejected. Do not relabel old handoffs or change forcing to
make reuse pass; finish all source changes before the final Offline/Online pair.


#Offline Training:

```bash
$TDDT_ORCHESTRATOR_ROOT/scripts/run_training_workflows.sh --offline
```

#Online Guidance and Navigation:

Native launch-site validation uses fresh same-session FCU position only as a
reference check against the configured surveyed origin. It never overwrites
MESA navigation state. MESA drift is reported separately and is not treated as
physical relocation of a grounded, disarmed aircraft.

With `tdoc.rtmo.initial_navigation.attitude_source: native_ground_imu`, the first
grounded, disarmed, zero-throttle observation supplies MESA's initial roll/pitch
from the measured BODY_FRD support-force vector. Acceleration magnitude and gyro
rate must satisfy the initialization checks. Surveyed origin and mission-known yaw
remain the seed; FCU attitude/GPS are not estimator inputs. This happens once per
episode. Later samples always propagate the existing estimator without re-anchoring.

Layer2 records `provenance.layer2_wall_timings_s` in each cycle and evaluates all
buffered measured propagation steps before serializing the final packet. Isolated
Full-Fidelity model identity is rehashed at entry and exit; concurrent live Layer5
decisions retain independent checks. Certificate capability scans perform two
identity reads rather than one per bank row. These changes grant no flight authority.
Map/CRP readers reuse only source lookups across isolated FF runtimes. Source paths
and file identity are checked before reuse; engines, FMUs, STD and simulation state
remain isolated. A changed source invalidates that reader before the next replay.
The existing bootstrap stall limit also applies before the first artifact is
published; repeated rejection ends with `online_l4_bootstrap_stalled` and recorded
Full-Fidelity rejection reasons.

Online FF selection produces current first-move physical predictions through the
existing Layer2/Layer3 replay lane. A reused feasibility certificate alone does
not supply the prediction needed by Layer7. Fast artifact reuse preserves both
the original prediction snapshot and the current network snapshot; Layer7 checks
their canonical hashes separately without changing forecast timestamps or hashes.
Completed Native segment observations are validated at their recorded capture
time for residual diagnostics only. They never acquire current observation,
navigation, persistent-learning or actuation authority. A rejected Layer7 input
is saved as a failure while retaining the already executed Layer6 evidence.

Native segment responses retain canonical telemetry metadata once rather than
duplicating private aliases. Oversized responses report their encoded byte size
and transport limit. Compressed KStore workspaces have idempotent close and reject
sync after close or loss of their temporary directory; closing a client twice must
not remove durable knowledge.

After a qualified takeoff bootstrap, the Native on-ground lifecycle edge uses a
fresh grounded/disarmed/zero-throttle FCU observation. It does not repeat a full
passive control transaction before the first controlled cycle. This edge grants
no actuation or navigation freshness; the next cycle still acquires actual IMU,
propagates MESA and passes the ordinary L4/L5/L6 gates.

Persistent workspace close is idempotent. Calling close twice must not synchronize
a deleted temporary directory back over committed SS/SETD metadata. Sync after
close is rejected, including after a failed terminal flush.

The optional `scripts/bridge_layer5_layer6_layer7.py --execute` entry point now
delegates to the same current-state mission workflow, including Layer7 processing
and feedback routing. Stored Layer5 packets are input-review artifacts and are
never replayed as execution authority. Without `--execute` it only checks input.

```bash
$PYTHON -m tddt_tdoc.cli \
  --config configs/tdoc.yaml \
  nav-online \
  --reuse-existing-offline-knowledge \
  --online-episodes 1 \
  --online-max-cycles-per-episode-auto
```




--------------------------
#cleanup flightstack space:

./cleanup_flightstack_v3.sh \
  --ardupilot-dir layer6_v20261007_1032/FlightStack/ardupilot \
  --jsbsim-dir layer6_v20261007_1032/FlightStack/jsbsim \
  --dry-run


./cleanup_flightstack_v3.sh \
  --ardupilot-dir layer6_v20261007_1032/FlightStack/ardupilot \
  --jsbsim-dir layer6_v20261007_1032/FlightStack/jsbsim \
  --apply

## Local Native hover commissioning (2026-11-04)

The optional local profile uses the normal L2/L3/L4/L5 execution gates and the
same six Native panels. From `TDOC_v20260911_2052`, after sourcing the environment
and accepting an Offline handoff for the **current** source/configuration:

```bash
$PYTHON -m tddt_tdoc.cli --config configs/tdoc.yaml nav-online \
  --reuse-existing-offline-knowledge --online-episodes 1 \
  --online-max-cycles-per-episode 12 \
  --online-local-hover-seconds 1 --online-local-hover-height-m 3
```

This selects `on_ground -> vertical_takeoff -> hover -> vertical_landing ->
touchdown` around the surveyed origin. Normal route missions keep their eleven
phases. Valid durations are 1..60 seconds and heights 1..10 metres. The duration
counts measured, contiguous, executed control with accepted Layer7 feedback,
within 5 metres horizontally and 1 metre vertically; ground time, missing
feedback and gaps in execution coverage never count. Only increase the duration
to 5/10/30/60 after the preceding level passes and touchdown is recorded.

With `tdoc.rtmo.initial_navigation.ground_calibration_seconds: 5.0`, startup
collects a sealed, same-session stationary/disarmed/zero-throttle IMU interval.
It initializes the existing MESA gyro/accelerometer bias inputs once. Raw samples
remain unchanged; FCU position/attitude do not re-anchor MESA. A missing, moving,
expired or foreign-session calibration is rejected. This is initialization, not
evidence of dynamic estimator or hover accuracy.

Any Python/configuration change covered by the model identity requires a fresh
compatible Offline handoff before Online reuse. Do not edit certificate hashes,
reset, refresh forcing or clear KStore after accepting that handoff. Short
diagnostic Offline runs used during integration do not demonstrate a completed
Offline flight mission.

This profile is an integration test, not an accepted hover result. The measured
Native outcome, remaining gates, source patch, hashes and screenshots are in
`integration_hover_20261104_1710/FINAL_NATIVE_REPORT_FA.html`. Opening panels or
reaching ARM alone does not pass the closed-loop flight test.


## Native realtime VTOL prototype (sensor-only navigation profile)

The integrated config now selects `tdoc.realtime.enabled: true`. The canonical
`nav-online` command routes through the explicit realtime Layer2–7 profile.
See `layer6_v20261007_1032/docs/NATIVE_REALTIME_VTOL_FA.md` for its sensor boundary,
clock/lease contract, EKF3 configuration and qualification limits. Allow the
configured 60-second stationary sensor calibration before ARM.

After compiled source changes, rebuild before producing a new compatible prior:

```bash
source "$TDDT_ORCHESTRATOR_ROOT/configs/environment_fixed.sh"
"$TDDT_LAYER6_ROOT/scripts/install_flightstack_rev1.sh" \
  --base-dir "$TDDT_LAYER6_ROOT" --repair-model-only
cd "$TDDT_ORCHESTRATOR_ROOT"
$PYTHON -m tddt_tdoc.cli --config configs/tdoc.yaml reset \
  --refresh-external --reuse-downloaded-datasets --climate-hours 24 \
  --build-fmus --build-fmus-refresh
./scripts/run_training_workflows.sh --offline
$PYTHON -m tddt_tdoc.cli --config configs/tdoc.yaml nav-online \
  --reuse-existing-offline-knowledge --online-episodes 1 \
  --online-max-cycles-per-episode-auto
```

Do not reset or refresh forcing between accepting that prior and Online. A new
build changes artifact identities and requires a new compatible Offline prior.
A short commissioning run may add `--online-local-hover-seconds 60
--online-local-hover-height-m 3`; this is a hover test, not a destination mission.
A cycle's prediction, actual MAVLink execution receipt and Layer7 feedback are
recorded in `runtime/realtime/<run-id>/cycles.jsonl`. Physical simulator pose is
retained separately for independent validation and is never a MESA observation.
