# وصلهٔ نمایش VTOL فونیکس در نقشهٔ MAVProxy

این وصله فقط نصب و نمایش را تغییر می‌دهد. پنج PNG اصلی کاربر بدون تغییر بایت‌ها
در `assets/` حفظ شده‌اند؛ شناسهٔ Drive، اندازه و SHA-256 در
`assets_manifest.json` ثبت شده‌اند. نام اصلی `orengephoniex.png` حفظ شده و به
رنگ `orange` نگاشت می‌شود.

## نصب کامل

پس از بارگذاری محیط TDOC و تعیین مسیر آرشیوهای نصب:

```bash
bash "$TDDT_LAYER6_ROOT/scripts/install_flightstack_with_phoenix_icons.sh" \
  --base-dir "$TDDT_LAYER6_ROOT" --assets-dir "$TDDT_FLIGHTSTACK_ASSETS"
```

این ورودی ابتدا نصب‌کنندهٔ موجود `install_flightstack_rev1.sh` را با همان
آرگومان‌ها اجرا می‌کند و پس از موفقیت، تصاویر را نصب می‌کند. نصب‌کنندهٔ اصلی
و منابع مدل مقید به hash تغییر نکرده‌اند.

## افزودن وصله روی نصب موجود PASS

```bash
bash "$TDDT_LAYER6_ROOT/scripts/install_flightstack_with_phoenix_icons.sh" \
  --base-dir "$TDDT_LAYER6_ROOT" --icons-only
```

این حالت ابتدا وابستگی‌های Map/Console را با ابزار قبلی بررسی می‌کند؛ سپس
تصاویر را نصب می‌کند. reset، آموزش، دانلود، build یا تغییر KStore ندارد.
اجرای مجدد idempotent است و فایل همسان دوباره نوشته نمی‌شود.

## نگاشت و دامنهٔ نمایش

| رنگ MAVProxy | فایل اصلی فونیکس |
| --- | --- |
| red | redphoniex.png |
| green | greenphoniex.png |
| blue | bluephoniex.png |
| purple | purplephoniex.png |
| orange | orengephoniex.png |

برای هر رنگ، aliasهای هواگرد `plane`، `copter`، `heli`، `singlecopter` و
`blimp` با همان تصویر نصب می‌شوند: ۲۵ alias هواگرد و پنج نام صریح
`COLORphoenix.png`. بنابراین انتخاب نوع هواگرد از HEARTBEAT یا fallback
نمایش موقعیت، شکل عمومی هواپیما/کوادکوپتر را برنمی‌گرداند. scope همین MAVProxy
باندل است؛ سایر هواگردهای یک نشست چندوسیله‌ای نیز همین artwork را خواهند داشت.
آیکن HOME، waypoint، نشانگرها، خودرو و قایق تغییر نمی‌کنند.

مسیر موجود `layer6.native_panels` موقعیت فیزیکی را با آیکن سبز نمایش می‌دهد؛
`greenplane.png` یا alias نوع هواگرد به تصویر سبز فونیکس می‌رسد. مختصات، چرخش
heading، trail، follow و معنای رنگ‌ها حفظ می‌شوند. SIM_STATE همچنان برای نمایش
و ارزیابی است و به ناوبری MESA وارد نمی‌شود.

## محیط نصب و بررسی

در نصب جابه‌جاشده، shebang فایل `bin/mavproxy.py` به محیط قدیمی خارج از باندل
اشاره می‌کرد. نصب‌کننده فقط خط shebang را به Python همین محیط Native متصل
می‌کند؛ بدنهٔ launcher و سورس MAVProxy تغییر نمی‌کنند. نصب‌کننده خارج از محیط
Native تعیین‌شده یا با import خارجی MAVProxy متوقف می‌شود.

بررسی بدون نوشتن:

```bash
bash "$TDDT_LAYER6_ROOT/scripts/install_flightstack_with_phoenix_icons.sh" \
  --base-dir "$TDDT_LAYER6_ROOT" --check-icons
```

علاوه بر hash تصاویر، پیکسل‌های خروجی فراخوانی واقعی `mp_tile.mp_icon` برای
هر ۲۵ alias با منبع تطبیق داده می‌شوند. hook یا ماژول ارسال فرمان جدیدی وجود
ندارد. manifest نصب در `FlightStack/runtime/phoenix_map_icons/INSTALL_MANIFEST.json`
و بایت‌های قبلی فایل‌های جایگزین‌شده در `backups/` همان پوشه حفظ می‌شوند.

## پایداری و بازنصب

منابع اصلی و نصب‌کننده داخل باندل‌اند. reset عادی TDOC که محیط نصب‌شدهٔ MAVProxy
را حذف نمی‌کند، تصاویر را بازنمی‌گرداند. اگر محیط Native حذف یا MAVProxy
بازنصب/upgrade شود، مرحلهٔ نصب تصاویر را تکرار کنید. ورودی نصب کامل بالا این
مرحله را خودکار انجام می‌دهد؛ فراخوانی مستقیم نصب‌کنندهٔ قدیمی چنین کاری نمی‌کند.

برای حفظ prior پذیرفته‌شده، آزمون این وصله reset یا بازسازی مدل انجام نمی‌دهد؛
ادعای اجرای تازهٔ reset مطرح نیست. هیچ جزء کامپایل‌شونده‌ای تغییر نکرده و rebuild
برای این وصله لازم نیست.

## اجرای آنلاین و شواهد

از شاخهٔ TDOC:

```bash
source configs/environment_fixed.sh
"$PYTHON" scripts/run_online_with_reports.py --config configs/tdoc.yaml
```

این ورودی فرمان canonical را بدون تغییر مسیر/مقصد اجرا می‌کند. گزارش‌ها و
تصاویر شش پنل در `reports/online/runs/<run-id>/` ثبت می‌شوند. بررسی PNG یا
بازشدن پنجره، به‌تنهایی PASS پرواز نیست؛ نتیجهٔ Native و ارزیابی مستقل جدا ثبت
می‌شوند. شواهد آزمون وصله در `integration_phoenix_icons_20261106/` هستند.
