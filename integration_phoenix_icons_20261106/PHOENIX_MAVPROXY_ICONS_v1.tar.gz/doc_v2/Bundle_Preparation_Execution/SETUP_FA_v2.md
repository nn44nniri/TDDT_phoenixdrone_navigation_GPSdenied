# آماده‌سازی و اجرای مرحله‌به‌مرحلهٔ باندل به‌روزشده

## الحاقیهٔ نصب آیکن فونیکس — ۲۰۲۶-۱۱-۰۶

برای نصب کامل همراه آیکن‌های سفارشی MAVProxy از ورودی جدید استفاده شود:

```bash
bash "$TDDT_LAYER6_ROOT/scripts/install_flightstack_with_phoenix_icons.sh" \
  --base-dir "$TDDT_LAYER6_ROOT" --assets-dir "$TDDT_FLIGHTSTACK_ASSETS"
```

این ورودی نصب‌کنندهٔ اصلیِ ذکرشده در ادامه را اجرا می‌کند و پس از آن آیکن‌ها
را می‌افزاید. روی نصب موجود PASS فقط مرحلهٔ زیر لازم است؛ reset و build ندارد:

```bash
bash "$TDDT_LAYER6_ROOT/scripts/install_flightstack_with_phoenix_icons.sh" \
  --base-dir "$TDDT_LAYER6_ROOT" --icons-only
```

جزئیات نگاشت پنج رنگ، محیط Python، بررسی بدون نوشتن و بازنصب در
[راهنمای وصله](../../presentation/phoenix_mavproxy_icons/README_FA.md) آمده است.
این الحاقیه محلی است؛ انتشار تازهٔ این سند روی Drive در این مرحله انجام نشده است.

[فهرست مجموعه](../README_FA.md)

## دامنهٔ معتبر این ویرایش و تقدم قراردادها

این ویرایش در ۲۰۲۶-۱۱-۰۵، منطقهٔ زمانی تورنتو، برای باندل `TDDT_integrated_fix_v4` تدوین شده است. مبنای اجرایی آن سورس ثبت‌شده در `integration_realtime_20261104_1855` و نشست `attempt20_full_route` است. این تاریخ، تاریخ تدوین مستندات است؛ آزمون مبنا در ۲۰۲۶-۱۱-۰۴ انجام شده است.

نام پروفایل جاری `native-sensor-vtol-prototype-v1` و کلید انتخاب آن `tdoc.realtime.enabled: true` است. در این پروفایل، TDOC مالک ترتیب اجراست و توابع واقعی بسته‌های لایه‌های ۲ تا ۷ را فراخوانی می‌کند. آرایهٔ فرمان سطح خلبان به GUI و سپس MAVLink می‌رسد و ArduPilot/JSBSim دوقلوی فیزیکی هستند.

**تقدم معنایی:** بخش «قرارداد اجرایی این ویرایش» بر گزاره‌های ناسازگار بخش مرجع طراحی، فقط در محدودهٔ همین پروفایل Native، مقدم است. بخش مرجع طراحی تمام مباحث و روابط قبلی را حفظ می‌کند، اما خواندن یک رابطه یا وجود نام آن در سند، به معنی اجرا یا اثبات آن در آزمون PASS نیست. فرمالیسم اصلی، مسیر قدیمیِ سخت‌گیرانه و پروفایل اجرایی جدید سه مفهوم متمایزند.

| موضوع | آنچه در نسخهٔ PASS اجرا شده است | آنچه از این آزمون نتیجه نمی‌شود |
| --- | --- | --- |
| مأموریت | جابه‌جایی VTOL از مبدأ اصلی تا محدودهٔ مقصد و فرود | تأیید transition بال‌ثابت یا همهٔ فازهای مأموریت ۱۱مرحله‌ای |
| MESA | propagator اصلی FMU، تصحیح وضعیت با حسگرهای مجاز، covariance مکمل ۹بعدی مکان/سرعت/باد | پیاده‌سازی کامل تمام anchorها و covariance ۲۹بعدی فرمالیسم اصلی |
| لایهٔ ۳ | snapshot اتمیک از سه دوقلو با hash و روابط صریح جاری | فعال‌بودن تمام جست‌وجوهای توپولوژی، شاخص‌های L‑EPAC و همهٔ تحلیل‌های نظری شبکه |
| لایهٔ ۴ | ۹ rollout محدود با مدل کاهش‌یافتهٔ پاسخ ArduPilot و شتاب جاری WingMPET | گواهی کامل FF، Pareto چندهدفه یا tube مقاومِ فرمالیسم اصلی |
| لایهٔ ۵ | انتخاب candidate با کمترین هزینه، کنترل MPC محدود و کنترل‌های اجرایی RTA | اثبات پایداری سراسری، recursive feasibility یا گواهی کامل ERA-qLPV-MPC |
| لایهٔ ۷ | residual حسگرمحور، تطبیق زمانی با فرمان اجراشده و اصلاح مدل WingMPET | صحت‌سنجی با موقعیت حقیقی در مسیر ناوبری یا مجوز یادگیری میدانی پایدار |
| prior | دانش جزئی آفلاین سازگار با مدل و forcing، با scope هویت مدل | آموزش کامل همهٔ فازها یا authority پرواز از گواهی قدیمی |
| محیط آزمون | SITL با نویز تصادفی پایهٔ IMU و `SIM_DRIFT_SPEED=0` | ناوبری نامحدود با drift حسگر واقعی یا گواهی پرواز سخت‌افزاری |

قبولی به یک نشست Native و معیارهای ثبت‌شدهٔ همان نشست محدود است. تغییر مدل، پارامتر، forcing، سورس یا binary، قبولی تاریخی را به نتیجهٔ اجرای تازه تبدیل نمی‌کند. هیچ odometry، بینایی یا حسگر جدیدی برای رسیدن به PASS اضافه نشده است.


## آماده‌سازی باندل به ترتیب قابل بازتولید

مسیر نمونهٔ محلی زیر مربوط به ماشین آزمون است؛ روی ماشین دیگر فقط ریشهٔ واقعی باندل جایگزین شود. تمام دستورهای TDOC از شاخهٔ آن اجرا می‌شوند. فایل setup جدید، توضیحات مسیر قدیمی را با انتخاب صریح پروفایل جدید تکمیل می‌کند.

```bash
cd /media/p1/DigitalTwin/TDDT_navigation/TDOC/code/chatgpg/reference_v4/TDDT_integrated_fix_v4/TDOC_v20260911_2052
source configs/environment_fixed.sh
"$PYTHON" -m pip install --upgrade pip setuptools wheel
"$PYTHON" -m pip install \
  -r "$TDDT_ORCHESTRATOR_ROOT/requirements.txt" \
  -r "$TDDT_BOULDER_ROOT/requirements.txt" \
  -r "$TDDT_SARG_PACKAGE_ROOT/requirements.txt" \
  -r "$TDDT_CLIMATE_ROOT/requirements.txt" \
  -r "$TDDT_LAYER3_ROOT/requirements.txt" \
  -r "$TDDT_LAYER4_ROOT/requirements.txt" \
  -r "$TDDT_LAYER5_ROOT/requirements.txt" \
  -r "$TDDT_LAYER7_ROOT/requirements.txt"
```

برنامهٔ GUI و وابستگی‌های Native از requirements/installer خود لایهٔ ۶ می‌آیند؛ صحت dependency نقشه و Console باید جدا کنترل شود. وجود ArduPilot و JSBSim به‌تنهایی کافی نیست. برای نصب اولیهٔ FlightStack، آرشیوهای asset ورودی لازم‌اند؛ وجود پوشهٔ `essential_data` در همین باندل فرض نمی‌شود:

```bash
: "${TDDT_FLIGHTSTACK_ASSETS:?مسیر واقعی آرشیوهای نصب FlightStack را تعیین کنید}"
"$TDDT_LAYER6_ROOT/scripts/install_flightstack_rev1.sh" \
  --base-dir "$TDDT_LAYER6_ROOT" --assets-dir "$TDDT_FLIGHTSTACK_ASSETS"
```

روی نصب موجود، نصب اولیه تکرار نشود. در صورت نیازِ بازسازی سورس/مدل از دستور استاندارد فصل build استفاده شود. پیش از آموزش، reset/آماده‌سازی و rebuildهای لازم کامل شوند؛ پس از پذیرش دانش، همین کارها روی نشست Online انجام نشوند.

```bash
"$TDDT_LAYER6_ROOT/scripts/install_flightstack_rev1.sh" \
  --base-dir "$TDDT_LAYER6_ROOT" --check-replay-map
"$PYTHON" -m tddt_tdoc.cli --config configs/tdoc.yaml preflight
```

`preflight` سلامت مسیرهای package، FMU، dataset و قراردادهای قابل بررسی را می‌سنجد؛ گواهی پرواز نیست. محیط گرافیکی فعال، `DISPLAY` معتبر و دسترسی به پنجره‌های X11 برای پنجره‌های Native و ثبت تصویر لازم است. در حالت headless یا بدون اتصال واقعی Map/Console، آزمون شش‌پنجره‌ای PASS محسوب نمی‌شود.

بعد از تکمیل build و dataset، آموزش آفلاین انجام و handoff سازگار پذیرفته می‌شود. پیکربندی جاری باید `tdoc.realtime.enabled: true` و profile جدید را داشته باشد. برای بازتولید آزمون اصلی، مقصد region تغییر نمی‌کند و گزینه‌های کوتاه‌کردن مسیر یا hover به فرمان اصلی اضافه نمی‌شوند.

```bash
"$PYTHON" -m tddt_tdoc.cli \
  --config configs/tdoc.yaml \
  nav-online \
  --reuse-existing-offline-knowledge \
  --online-episodes 1 \
  --online-max-cycles-per-episode-auto
```

این فرمان در پیکربندی جاری پروفایل realtime را انتخاب می‌کند. پرچم صریح `--online-realtime-vtol` برای انتخاب آن در تنظیماتی که `enabled=false` دارند موجود است؛ تعویض ضمنی مسیر قدیمی و جدید در گزارش مجاز نیست. یک episode و prior پذیرفته‌شده لازم‌اند. `--online-realtime-output /absolute/path` فقط مقصد فایل‌های شواهد را تعیین می‌کند و مقصد پرواز را عوض نمی‌کند.

خروجی اصلی شامل `startup.json`، `cycles.jsonl`، `telemetry_wire.jsonl` و `MISSION_RESULT.json` است. exit code صفر driver بدون ارزیابی مستقل، پایان کار نیست. برای commissioning محلی می‌توان `--online-local-hover-seconds 3 --online-local-hover-height-m 3` را جدا استفاده کرد؛ آن نتیجه، تست مسیر اصلی نیست. گزینهٔ `--online-realtime-goal-offset-m` مسیر را عوض می‌کند و نباید در بازتولید قبولی کامل استفاده شود.

آزمون‌های manual/gamepad و demoهای لایهٔ ۶ برای شناخت semantics مفیدند، ولی هم‌زمان با مالکیت فرمان TDDT نباید gamepad یا ابزار دوم فرمان پروازی صادر کند. ArduPilot/JSBSim دوم یا MAVProxy با portهای هم‌نام نیز شاهد همین نشست نیست.


## بازسازی استاندارد، نسخه و پایداری پس از reset

تنها سورس C++ اصلاح‌شده در این فرایند `twins_layer2_v20260820_1233/src/wingmpet/model.cpp` است. تغییر blend در سورس اصلی ثبت شد؛ FMUها با ابزار استاندارد دوباره ساخته شدند و داخل آرشیو نیز سورس جدید وجود دارد. فایل‌های Python و XML تفسیرشونده به build C++ مستقل نیاز ندارند، اما جزو هویت مدل‌اند. تغییر سورس ArduPilot/JSBSim در آینده نیز به build و تست binary تازه نیاز دارد؛ کپی‌کردن binary قدیمی کافی نیست.

reset واقعی پیش از آموزش/Online نهایی اجرا شد:

```bash
"$PYTHON" -m tddt_tdoc.cli --config configs/tdoc.yaml reset \
  --refresh-external --reuse-downloaded-datasets --climate-hours 24 \
  --build-fmus --build-fmus-refresh
```

این فرمان باید از شاخهٔ TDOC و پس از بارگذاری محیط اجرا شود. `--reuse-downloaded-datasets` برای cache موجود است؛ نبود cache را نباید با دادهٔ ساختگی پوشاند. اجرای بدون cache می‌تواند این گزینه را حذف کند. زنجیرهٔ `scripts/prepare_all.sh` در reset، نقشه/DEM، موانع، اقلیم و CRP/SARG/TEP را آماده می‌کند. موفقیت `reset` و preparation و `COMMITTED` بودن transaction در شواهد ثبت شد؛ سورس Wing باقی ماند و shared object بازسازی‌شده با build جدید پیش از reset یکسان بود.

برای FlightStack نصب‌شده، repair/build استاندارد استفاده شد:

```bash
"$TDDT_LAYER6_ROOT/scripts/install_flightstack_rev1.sh" \
  --base-dir "$TDDT_LAYER6_ROOT" --repair-model-only
```

این نام گزینه به معنی مجاز بودن تعویض خروجی بدون سورس نیست. installer توالی overlayهای مبنا، build ArduPilot و refreshهای لازم را انجام می‌دهد و مدل/پارامتر Native جدید را در پایان اعمال می‌کند. خطای refresh پس از build که دوباره نسخهٔ قبل از R6 را تحمیل می‌کرد اصلاح شد. دو اجرای نهایی همین build با همان پروفایل، SHA‑256 یکسان ArduPlane تولید کردند.

مولد مدل `scripts/apply_native_realtime_model.py`، ورودی `configs/phoenix_native_base.xml` و پارامتر `configs/native_realtime_vtol.parm` را می‌خواند. overlay محیط با `scripts/apply_native_realtime_environment.py` از resource مقید R4 ساخته می‌شود؛ installer پیش از restore استاندارد، overlay تولیدشده را به مبنا برمی‌گرداند و بعد از آن دوباره اعمال می‌کند. بنابراین تغییر فقط در فایل تولیدشدهٔ `FlightStack/.../bound.py` ثبت نشده است.

اثبات build باید شامل hash سورس اصلی، سورس embedded FMU، آرشیو FMU، shared object، XML، پارامتر و binary باشد. hash کامل نسخهٔ PASS در سند `BUILD_HASHES_FA_v2.md` آمده است. model ID نهایی برابر است با:

```text
14e38c50ad391ce77e80c1bd316c7785438e61b7afa3ba5062541fae8999c73c
```

دانلود dependencyهای تازه یا نصب package جدید ممکن است نتیجهٔ آینده را تغییر دهد؛ فایل‌های requirements و installer نسخهٔ باندل مرجع‌اند. این مستندات قفل محیط تازه یا build تازه‌ای ایجاد نمی‌کنند. **برای صرفاً خواندن/انتشار این ویرایش مستندات، reset یا بازآموزی اجرا نشده است** تا دانش و forcing نشست مبنا دست‌نخورده بمانند.


## آموزش، SETD/KStore و هویت prior

CRP توصیف context محیطی/توپوگرافی، SARG سناریو و مرجع، و TEP محدودهٔ تجربه/اعتبار دوقلو را نگه می‌دارند. این‌ها با state تازه و receipt اجرا یکسان نیستند. Single-Episode، SS-KStore و SETD/handoff از روند آفلاین تولید می‌شوند؛ مسیر جدید نباید برای رفع مانع، یک گواهی قدیمی را با model ID جدید برچسب بزند.

پیش از Native، `OfflineKnowledgeHandoff.validate_online_start` integrity و آماده‌بودن handoff نهایی‌شده را می‌سنجد. هویت مدل از sourceها، FMUها، binaryهای Native، پارامترها، مولدها، مدل XML و وابستگی‌های ثبت‌شده ساخته می‌شود. policyها و forcing نیز به binding وابسته‌اند. `model_compatibility.py` علاوه بر hashها، تطابق سورس C++ داخل FMU با سورس جاری و یکسانی خروجی مدل نصب‌شده/packaged را بررسی می‌کند. patch کردن فقط فایل `.so` یا فقط XML نصب‌شده، مسیر استاندارد بازسازی محسوب نمی‌شود.

در نشست PASS، prior از **سه cycle آفلاین عیب‌یابی** ساخته شد. آن آموزش تا touchdown ادامه نیافت و exit code آن ۲ بود. با وجود آن، handoff جزئیِ نهایی‌شده و سازگار، با scope `MODEL_IDENTITY_ONLY` برای این پروفایل پذیرفته شد. `flight_authority=false` و `current_state_replaced=false` بودند. این خروجی نباید آموزش کامل، پوشش همهٔ فازها یا گواهی آماده‌بودن کنترل مأموریت معرفی شود. پذیرش محدودِ هویت مدل در این مسیر با gate کنترل کامل مسیر قدیمی متفاوت است.

prior در پروفایل جاری نقش eligibility/سازگاری مدل و زمینهٔ قبلی را دارد. خود `RealtimeTwins` تخمین جاری را از حسگرهای نشست و مدل را از مقدار اولیهٔ تعریف‌شده شروع می‌کند؛ trajectory یا فرمان episode قبلی را پخش نمی‌کند. ادعای استفادهٔ عملی از همهٔ مدل‌های آموخته‌شده، بانک candidateهای قدیمی یا همهٔ پارامترهای SETD از این PASS نتیجه نمی‌شود. برای توسعهٔ چنین warm-startهایی باید محل مصرف و شواهد آن جدا ثبت شود.

روند پیشنهادی بهره‌برداری، آموزش کامل است:

```bash
"$TDDT_ORCHESTRATOR_ROOT/scripts/run_training_workflows.sh" --offline
```

برای بازتولید **شرط جزئی آزمون مستند**، فرمان زیر استفاده شد؛ خروجی عدم تکمیل مأموریت باید حفظ شود و نباید به PASS آموزش تغییر داده شود:

```bash
"$PYTHON" "$TDDT_ORCHESTRATOR_ROOT/scripts/run_training_workflows.py" \
  --offline --offline-max-cycles 3
```

پس از پذیرفتن prior برای Online، reset، refresh خارجی، تغییر forcing/epoch، پاک‌سازی KStore و تغییر source/binary مجاز به پنهان‌ماندن نیستند. اگر یکی تغییر کند، این prior دیگر همان prior آزموده‌شده نیست؛ باید ناسازگاری ثبت و برای نسخهٔ تکمیل‌شدهٔ جدید دانش تازه تولید شود. خاموش‌کردن gate یا retag کردن handoff راه‌حل نیست.

در اجرای نهایی، source، YAML، handoff، فایل‌های KStore، forcing و binaryها قبل/بعد Online برابر بودند. این به معنی برابر بودن binaryهای ابتدای کل فرایند عیب‌یابی با binary نهایی نیست: WingMPET واقعاً اصلاح و بازکامپایل شد و ArduPilot نیز در build استاندارد بازسازی شد. معیار حفظ هویت، نشست نهایی است و اثبات rebuild/reset جدا نگه‌داری می‌شود.


## Layer‑6، مسیر GUI و قرارداد زمانی واقعی

مسیر اجرا عبارت است از `Layer5 → Layer6Client.submit_command → intake/validation → semantic pilot state → command latch → Phoenix GUI → MANUAL_CONTROL/MODE/ARM MAVLink → ArduPilot → JSBSim`. ورودی gamepad در هدایت خودکار منبع فرمان نیست؛ همان semantics GUI توسط Digital Pilot تحریک می‌شود. اتصال جداگانهٔ RealtimeIO فرمان پروازی ارسال نمی‌کند و برای stream/parameter/frame و دریافت تله‌متری است.

شش پنجرهٔ الزامی در طول Online باید به همین نشست وصل باشند: ArduPilot SITL، JSBSim backend observer، Environment Adapter، Phoenix GUI، MAVProxy Map و MAVProxy Console. پنجرهٔ JSBSim ناظر زندهٔ process/log و telemetry همان child است و شبیه‌ساز دوم راه نمی‌اندازد. فقط باز بودن یک پنجره شرط کافی نیست؛ session ID، heartbeat و وضعیت Map/Console و physical map باید fresh باشند.

اجرای همین پروفایل با `MAVLINK20=1` انجام می‌شود. fanoutهای Native شامل TCP `14552` برای GUI، TCP `14553` برای RealtimeIO و UDP `14551` برای Environment Adapter هستند. دریافت‌کنندهٔ RealtimeIO با source `254/192` فقط تله‌متری FCU `1/1` را قبول می‌کند. UDP `14660` برای درخواست receipt سریع GUI است؛ پاسخ باید peer، schema، request ID و session ID درخواست را تطبیق دهد. این درگاه جای MAVLink execution نیست.

| زمان/نرخ | قرارداد پروفایل جاری |
| --- | --- |
| تصمیم TDOC | هدف ۱۰ Hz؛ jitter واقعی در cycle log ثبت می‌شود |
| سرویس اجرای فرمان | ۳۰ Hz، مستقل از زمان محاسبهٔ TDOC |
| lease هر فرمان | ۰٫۵ ثانیه |
| prediction اصلی | ۲ ثانیه از زمان source همان تصمیم |
| عمر IMU و عمر state پیش از ارسال | حداکثر ۰٫۳ ثانیه |
| timeout درخواست receipt سریع | ۰٫۱۲ ثانیه؛ نبود receipt، بازخورد جعلی تولید نمی‌کند |
| عمر MicroMet | حداکثر ۳ ثانیه، هم بر ساعت wall و هم source |

این یک قرارداد صریح تازه است. segment قدیمیِ ۱۰۰ میلی‌ثانیه‌ای و clock gate قدیمی به نام تازه تغییر داده نشده‌اند و قرار نیست PASS آن‌ها از این تست نتیجه گرفته شود. timestamp prediction برای پوشاندن latency جابه‌جا نمی‌شود. `max_cycle_wall_s=0.15334957` اندازه‌گیری نشست ۲۰ است، نه وعدهٔ deadline صد میلی‌ثانیه‌ای در تمام cycleها.

readiness مخصوص QHOVER/QSTABILIZE نیازمند attitude، velocity/vertical position معتبر، pre-arm واقعی و freshness است؛ نبود absolute horizontal position در این دو مد به‌تنهایی مانع نیست. readiness مربوط به QLOITER یا مد نیازمند GPS با این تغییر سست نشده است. profile از `AHRS_EKF_TYPE=3`، `EK3_ENABLE=1`، `EK2_ENABLE=0` و ماتریس source برابر `POSXY=0,VELXY=0,POSZ=1,VELZ=0,YAW=1` استفاده می‌کند.

startup با `INITIAL_MODE=18` یعنی QHOVER بدون ARM و `FLTMODE_CH=0` انجام می‌شود تا کلید RC بلااستفاده مد را به MANUAL برنگرداند. `AHRS_OPTIONS=2` مانع fallback نامناسب در شرایط VTOL بدون XY مطلق می‌شود. GPS1/2 و SIM_GPS1..4 خاموش‌اند و readback قبل از ARM بررسی می‌شود. normal ARM از مسیر GUI/Client و بدون force-arm صادر می‌شود.

receipt اجرای فرمان باید instance ID، transaction ID، requested GUI state، mode، write واقعی transport و ترتیب stream را ثبت کند. شاهد raw MANUAL_CONTROL و TIMESYNC و bound زمان ارسال، از اقرار نرم‌افزاری «ارسال شد» قوی‌تر است. receipt معتبر نیز به‌تنهایی touchdown یا موفقیت مأموریت نیست.

Map فیزیکی، نشانگر سبز و trailِ موقعیت JSBSim را فقط برای نمایش دارد. `GLOBAL_POSITION_INT` نامعتبر EKF بدون XY، ناوبری MESA را صفر نمی‌کند و روی نقشه مرجع فیزیکی محسوب نمی‌شود. دادهٔ Map به MESA یا residual کنترلی برنمی‌گردد. تصویر بعد از DISARM ممکن است انقضای lease و `HOLD unverified; output inhibited` نشان دهد؛ این پیام، HOLD تأییدشده در پرواز تلقی نمی‌شود.
